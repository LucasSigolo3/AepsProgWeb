export enum ErrorMessages {
    INVALID_OPERATION = "INSIRA UM NUMERO VALIDO"
}